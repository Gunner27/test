#include "helloWorld.h"

std::string HelloWorld::helloWorld() const {
    return std::string("Hello World!");
}