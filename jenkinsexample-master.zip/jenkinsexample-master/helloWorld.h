#ifndef JENKINSEXAMPLE_HELLOWORLD_H
#define JENKINSEXAMPLE_HELLOWORLD_H

#include <string>

class HelloWorld {
public:
    std::string helloWorld() const;
};

#endif //JENKINSEXAMPLE_HELLOWORLD_H
